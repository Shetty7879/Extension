Research Summary:
- Malicious extensions can act like spyware.
- Google and Mozilla regularly remove harmful add-ons.
- Always verify developers and read reviews before installing.
